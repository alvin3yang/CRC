class Car:
    car_id = 0
    car_makename = ''
    car_model = ''
    car_series = ''
    car_series_year = ''
    car_price_new = ''
    car_engine_size = ''
    car_fuel_system = ''
    car_tank_capacity = ''
    car_power = ''
    car_seating_capacity = ''
    car_standard_transmission = ''
    car_body_type = ''
    car_drive = ''
    car_wheelbase = ''
    store_id = 0

    def __init__(self):
        self.car_id = 0
        self.car_makename = ''
        self.car_model = ''
        self.car_series = ''
        self.car_series_year = ''
        self.car_price_new = ''
        self.car_engine_size = ''
        self.car_fuel_system = ''
        self.car_tank_capacity = ''
        self.car_power = ''
        self.car_seating_capacity = ''
        self.car_standard_transmission = ''
        self.car_body_type = ''
        self.car_drive = ''
        self.car_wheelbase = ''
        self.store_id = 0
